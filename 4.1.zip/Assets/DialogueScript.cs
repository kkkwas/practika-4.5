using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class DialogueScript : MonoBehaviour
{
    public string[] Dialogue;
    public int count;
    public TMP_Text text;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        text.text = Dialogue[count];
    }
    public void Next()
    {
        count++;
    }
    public void Prev()
    {
        count--;
    }
}
