using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LoadScenes : MonoBehaviour
{
    public GameObject mainMenuButtons;
    public GameObject settingsButtons;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void ShowSettings()
    {
        mainMenuButtons.SetActive(false);
        settingsButtons.SetActive(true);
    }
    public void ShowMainMenu()
    {
        mainMenuButtons.SetActive(true);
        settingsButtons.SetActive(false);
    }
    public void Exit()
    {
      #if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
      #else
            Application.Quit();
      #endif
    }
    public void Load()
    {
        SceneManager.LoadSceneAsync(1);
    }
}
