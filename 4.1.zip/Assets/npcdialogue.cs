using UnityEngine;

public class NPCInteraction : MonoBehaviour
{
    public GameObject dialogueCanvas;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            StartDialogue();
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            EndDialogue();
        }
    }

    private void StartDialogue()
    {
        if (dialogueCanvas != null)
        {
            dialogueCanvas.SetActive(true);
        }
    }

    private void EndDialogue()
    {
        if (dialogueCanvas != null)
        {
            dialogueCanvas.SetActive(false);
        }
    }
}
